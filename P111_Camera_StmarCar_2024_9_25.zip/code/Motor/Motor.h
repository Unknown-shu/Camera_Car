#ifndef  _Motor_H
#define  _Motor_H

#include "PIN.H"

#define MOTOR_PWM_MAX 9000
#define MOTOR_PWM_MIN 9000


#endif
