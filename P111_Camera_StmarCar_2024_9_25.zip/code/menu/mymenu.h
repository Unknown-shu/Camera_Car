/*
 * mymenu.h
 *
 *  Created on: 2023��4��14��
 *      Author: ֣��
 */

#ifndef CODE_CPU2_MENU_MYMENU_H_
#define CODE_CPU2_MENU_MYMENU_H_

#include "menu.h"
#include "pin.h"
#include "Font.h"
#include "page_setting.h"

// extern float gyro_x,gyro_y,gyro_z;
// extern float acc_x,acc_y,acc_z;
// extern float pitch[2],roll[2],yaw[2];
extern int point_num;
extern int start_flag;

#endif /* CODE_CPU2_MENU_MYMENU_H_ */
