#ifndef  __Menu_Variable_H
#define  __Menu_Variable_H


extern uint8_t threshold_value_add;
extern uint8_t threshold_open_or_close;



#endif
