#ifndef __MYHEADFILE_H__
#define __MYHEADFILE_H__

#include "zf_common_headfile.h"
#include "PIN.h"
#include "Beep.h"
#include "mymenu.h"
#include "MyCamera.h"
#include "MyEncoder.h"
#include "Menu_Variable.h"


#endif
